var menuLi = document.body.querySelector(".dropdown"),
    subMenuLi1 = document.body.querySelector(".dropright"),
    subMenuLi2 = document.body.querySelector(".dropright-2"),
    subMenu1 = document.body.querySelector(".sub-menu-1"),
    subMenu2 = document.body.querySelector(".sub-menu-2"),
    subMenu3 = document.body.querySelector(".sub-menu-3"),
    anim,               // таймаут
    start,              // время старта
    now,                // текущее время
    duration = 800,    // продолжительность
    from = 0,           // стартовая позиция
    to = 50,            // финишная позиция
    progress = 0,       // прогресс анимации
    x;                  // позиция в текущий момент времени

// закон приращения аргумента (easingOutBounce)
function delta(param) {
     function d(param) {
        for(var a = 0, b = 1, result; 1; a += b, b /= 2) {
           if (param >= (7 - 4 * a) / 11)
               return -Math.pow((11 - 6 * a - 11 * param) / 4, 2) + Math.pow(b, 2);
        }
     }
     return 1 - d(1 - param);
}

// рендер
function render() {
    now = new Date().getTime();
    progress = (now - start) / duration;
    x = Math.round( (to - from) * delta(progress) + from );

    subMenu1.style.top = x + "px";

// если не конец выполняем анимацию еще
    if (progress < 1) anim = setAnimation(render)
// иначе заканчиваем анимацию
    else
        {
            clearAnimation(anim);
            progress = 0;
        };
    };

function hideSubMenu(el) {
    el.style.display = "";
};

menuLi.addEventListener("mouseover", function() {
    start = new Date().getTime();
    subMenu1.style.display = "block";
    render(subMenu1);
});

subMenu1.addEventListener("mouseout", function() {
    hideSubMenu(subMenu1)
    console.log(subMenu1.style.top);
});

//requestAnimFrame
window.setAnimation = (function() {
return  window.requestAnimationFrame||
        window.webkitRequestAnimationFrame||
        window.mozRequestAnimationFrame||
        window.oRequestAnimationFrame||
        window.msRequestAnimationFrame||
        function(/* function */callback, /* DOMElement */element) {
            return window.setTimeout(callback, 1000 / 60);
        };
})();

//canсelRequestAnimFrame
window.clearAnimation = (function() {
return	window.cancelRequestAnimationFrame||
        window.CancelAnimationFrame||
		// window.webkitCancelRequestAnimationFrame||
        window.mozCancelRequestAnimationFrame||
        window.oCancelRequestAnimationFrame||
        window.msCancelRequestAnimationFrame||
        function(id){clearTimeout(id)}
})();
